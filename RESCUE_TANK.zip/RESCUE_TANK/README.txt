                                                
///////////////////////////
// 	RESCUE TANK!	 //
///////////////////////////

RESCUE TANK! is a tongue-in-cheek humanitarian learning game. It was developed as a tech demo in C++ and SDL2 by 
Matthew Stevens of Lessons Learned Simulations and Training (mstevens@llst.ca / www.llst.ca).


Instructions:
-------------

Aim: A and D
Deliver Funds: Hold the space bar to charge the delivery. Release to send the delivery.


Game Rules:
-----------

The RESCUE TANK delivers life-saving supplies to people in need. 

As with all humanitarian operations, the tank requires funding to operate. If you are unable to secure adequate funding,
the humanitarian program will collapse. 

Aim the aid delivery device using the A and D keys. Hold down the spacebar to charge up the aid delivery vehicle. The longer
you hold the spacebar, the faster and the aid is dispatched. However, charging the delivery vehicle costs funds. The more you
charge the aid delivery vehicle, the more the delivery will cost.

Funding is provided by donors when the project team successfully delivers aid to communities in need.

Communities in need are represented by purple squares. As time passes, the community shrinks as the people living 
are faced with no option but to move on. Serving smaller communities means smaller funding rewards from donors. However, 
if you fail to serve a community, donors will reallocate your funding towards restrictive border control activities.
While a small community may be increasingly difficult to serve, and decreasingly lucrative for your organisation, you
will avoid punishment


Why Rescue Tank?
----------------

RESCUE TANK! is a tech demo. While it does explore some key real-life tensions between donors, humanitarian actors, and the people
we attempt to serve, including the increasing militarization of aid, it was created primarily as a skill-building exercise. Neither 
LLST nor Matthew Stevens advocates for the aid delivery methods featured in RESCUE TANK!.

This project was coded entirely in C++ and SDL2. It demonstrates the following abilities:

* Basic game engine development in C++, including:
	-establishing a main game loop, 
	-tracking of multiple game objects, 
	-collision detection, and
	-basic physics such as gravity and application of forces.
* Use of SDL2 libraries
* Dynamic memory management techniques
* Object pooling


Acknowledgements:
-----------------

RESCUE TANK! was created as a project for CMPT1267 at Douglas College. It would not have been possible without the instruction of 
Prof. Mohammad Aboofazeli. It also drew heavily on the text 'Game Programming in C++' by Sanjay Madhav.

RESCUE TANK! was designed to emulate the gameplay experience of Tank Wars (1986), Atari console games, and arcade games such as 
Missile Command.

The fantasic music in RESCUE TANK! was composed by Music composed and produced by Tomasz Kucza (http://magory.net/music): 
(licence: CC-BY 4.0 https://creativecommons.org/licenses/by/4.0/ ).



LESSONS LEARNED SIMULATIONS AND TRAINING
www.llst.ca


                     ?G555555555555555555555555555555555555555555555555555555G?                     
                    G&:    :^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^!&G                    
                  .&B     ?#?????????????????????????????????????????????????5#&#.                  
                 ^@Y     P#.   :Y???77777777777777777777777777777777777777777YG&#&^                 
                ?@!    .#P    !&^  .!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!JBP#B@?                
               P&:    :&?    YB.   G?:.~7777777777777777777777777777777777777G5BG##&P               
              ##     !&^    GP   :#~  :G^:!?77777777777777777777777777777777YY5PGGB#&#              
            :&5     5&.   .#?   !B.  7P  :5:^7777777777777777777777777777777J?5YG5BG##&:            
           !@7     BB    ~&^   YG   5Y  75  Y^.::::::::::::::::::::::::::.^J!Y7PJGYBP&#&!           
          Y@^    .&Y    J#.   GY  .G!  Y? .5.                              .Y!57PJGYBP#B&Y          
         B&.    ~&!    GG   .B!  :B: .P~ ~Y                                  J!Y?5JP5GGB#&B         
       .&G     J&:   .#J   ~#:  !G. :P. ??                                    ???JJ5YPPBG##&.       
      ~@J     G#    ^&~   ?B   J5  !5  Y~                                      ~J7Y?PJG5BG&#&~      
     J@~    .#5    7#.   P5   P?  JJ .5:                                        :Y!57P?GYBP#B&?     
    G&.    ^&7    5B   .B7  .G^  5! ^5                                            Y!Y75JP5GG##&P    
  .#B     7&^    G5   :B^  ^G. .P: !J                                              ?7J?YY5PGGB#&#.  
  #&     ^@^    BB    &~  .&.  #^ ^G                                                P^P~G7BJBP#B&#  
  .#B     7&^    G5   :B^  ^G. .P: !J                                              ?7J?YY5PGGB#&#.  
    G&.    ^&7    5B   .B7  .G^  5! ^5                                            Y!Y75JP5GG##&P    
     J@~    .#P    7#.   P5   P?  JJ .5:                                        :Y!57P?GYBP#B&?     
      ~@J     G#    ^&~   ?B   J5  !5  Y~                                      ~J7Y?PJG5BG&#&~      
       .&G     J&:   .#J   ~#:  !G. :G. ??                                    ???JJ5YPPBG##&.       
         B&.    ~&!    PG   .B!  :B: .P~ ~Y                                  J!Y?5JP5GGB#&B         
          Y@^    .&Y    J#.   GY  .G!  Y? .5.                              .Y!57PJGYBP#B&Y          
           !@7     BB    ~&^   YG   YY  75  Y^.::::::::::::::::::::::::::.^J!Y7PJGYBP&#&!           
            :&5     5&.   .#?   !B.  7P  :5:^7777777777777777777777777777777J?5YG5BG##&:            
              ##     !&^    GP   :#~  :G^:!?77777777777777777777777777777777YY5PGGB#&#              
               P&:    :&?    YB.   G?:.~7777777777777777777777777777777777777G5BG##&P               
                ?@!    .#P    !&^  .!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!JBP#B@?                
                 ^@Y     P#.   :Y???77777777777777777777777777777777777777777YG&#&^                 
                  .&B     ?#?????????????????????????????????????????????????5#&#.                  
                    G&:    :^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^!&G                    
                     ?G555555555555555555555555555555555555555555555555555555G?                                                                                      
                                                                                
                              